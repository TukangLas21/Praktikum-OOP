public interface Damageable {
    void takeDamage(int damage);
}