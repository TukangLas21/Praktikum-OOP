public interface Interactable {
    void interact();
}